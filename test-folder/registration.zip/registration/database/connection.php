<?php 
    $serveName = "localhost";
    $userName = "root";
    $password = "";
    $dbname = "socialentertainment";
    /** Conncetion Databse */
    $conn = mysqli_connect($serveName,$userName,$password,$dbname);
?>