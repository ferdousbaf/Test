
var fname, lname, email,fnsub,lnsub,esub,table_ref,insert_row, fname_col,lname_col,email_col,fnsub_col,lnsub_col,esub_col,action_col;
var tr1,cell_value0,cell_value1,cell_value2,cell_value3,cell_value4,cell_value5;


function createNewData(){
    fname = document.getElementById("fname").value;
    fnsub = document.getElementById("fnsub").value;
    lname = document.getElementById("lname").value;
    lnsub = document.getElementById("lnsub").value;
    email = document.getElementById("email").value;
    esub = document.getElementById("esub").value;
    table_ref = document.getElementById("mytab").getElementsByTagName("tbody")[0];
    insert_row = table_ref.insertRow(table_ref.rows.length);
    fname_col = insert_row.insertCell(0).innerHTML = fname;
    fnsub_col = insert_row.insertCell(1).innerHTML = '<td><a class="edit1_1 btn btn-primary" title="Edit" data-toggle="tooltip">Edit</a><a class="add1_1 btn btn-success" title="Add" data-toggle="tooltip">Save</a></td>';
    lname_col = insert_row.insertCell(2).innerHTML = lname;
    lnsub_col = insert_row.insertCell(3).innerHTML = '<td><a class="edit1_2 btn btn-primary" title="Edit" data-toggle="tooltip">Edit</a><a class="add1_2 btn btn-success" title="Add" data-toggle="tooltip">Save</a></td>';
    email_col = insert_row.insertCell(4).innerHTML = email;
    esub_col = insert_row.insertCell(5).innerHTML = '<td><a class="edit1_3 btn btn-primary" title="Edit" data-toggle="tooltip">Edit</a><a class="add1_3 btn btn-success" title="Add" data-toggle="tooltip">Save</a></td>';
    action_col = insert_row.insertCell(6).innerHTML = '<td><a class="edit btn btn-success" title="Edit">Edit</a><a class="add btn btn-info" title="Add">Save</a>' + 
    '<a class="delete btn btn-danger" title="Delete">Delete</a></td>';
   	

     $("#createNewData").click(function(){
		$(this).attr("disabled", "disabled");
		var index = $("table tbody #tr1:last-child").index();
    	$("table").append(row);		
		$("table tbody #tr1").eq(index + 1).find(".add, .edit").toggle();
        
    });

    $("#createNewData").click(function(){
		$(this).attr("disabled", "disabled");
		var index = $("table tbody tr:last-child").index();
    	$("table").append(row);		
		$("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        
    });


 // Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
			if(!$(this).val()){
				$(this).addClass("error");
				empty = true;
			} else{
                $(this).removeClass("error");
            }
		});
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});			
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".addnewbtn").removeAttr("disabled");
		}		
    });

	// Edit row on edit button click
	$(document).on("click", ".edit", function(){		
        $(this).parents("tr").find("td:nth-child(1),td:nth-child(3),td:nth-child(5)").each(function(){
			$(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');

		});		
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".addnewbtn").attr("disabled", "disabled");
    });
	// Delete row on delete button click
	$(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
		$(".addnewbtn").removeAttr("disabled");
    });


	// ============================1st Row 1st column====================
// Add row on add button click
    $(document).on("click", ".add1_1", function(){
        var empty = false;
        var input = $(this).parents("tr").find('input[type="text"]');
        // var button = $(this).parents("tr").find('button[type="button"]');
        input.each(function(){
            if(!$(this).val()){
                $(this).addClass("error");
                empty = true;
            } else{
                $(this).removeClass("error");
            }
        });
        $(this).parents("tr").find(".error").first().focus();
        if(!empty){
            input.each(function(){
                $(this).parent("td").html($(this).val());
            });         
            $(this).parents("tr").find(".add1_1, .edit1_1").toggle();
            $(".addnewbtn").removeAttr("disabled");
        }       
    });
// Edit row on edit button click
    $(document).on("click", ".edit1_1", function(){     
        $(this).parents("tr").find("td:first-child").each(function(){
            $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
        });     
        $(this).parents("tr").find(".add1_1, .edit1_1").toggle();
        $(".addnewbtn").attr("disabled", "disabled");
    });
    // Delete row on delete button click
    $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
        $(".addnewbtn").removeAttr("disabled");
    });

// ================================1st Row 2nd column==========================================================

// Add row on add button click
    $(document).on("click", ".add1_2", function(){
        var empty = false;
        var input = $(this).parents("tr").find('input[type="text"]');
        // var button = $(this).parents("tr").find('button[type="button"]');
        input.each(function(){
            if(!$(this).val()){
                $(this).addClass("error");
                empty = true;
            } else{
                $(this).removeClass("error");
            }
        });
        $(this).parents("tr").find(".error").first().focus();
        if(!empty){
            input.each(function(){
                $(this).parent("td").html($(this).val());
            });         
            $(this).parents("tr").find(".add1_2, .edit1_2").toggle();
            $(".addnewbtn").removeAttr("disabled");
        }       
    });
// Edit row on edit button click
    $(document).on("click", ".edit1_2", function(){     
        $(this).parents("tr").find("td:nth-child(3)").each(function(){
            $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
        });     
        $(this).parents("tr").find(".add1_2, .edit1_2").toggle();
        $(".addnewbtn").attr("disabled", "disabled");
    });
    // Delete row on delete button click
    $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
        $(".addnewbtn").removeAttr("disabled");
    });

// ================================1st Row 3rd column==========================================================

// Add row on add button click
    $(document).on("click", ".add1_3", function(){
        var empty = false;
        var input = $(this).parents("tr").find('input[type="text"]');
        // var button = $(this).parents("tr").find('button[type="button"]');
        input.each(function(){
            if(!$(this).val()){
                $(this).addClass("error");
                empty = true;
            } else{
                $(this).removeClass("error");
            }
        });
        $(this).parents("tr").find(".error").first().focus();
        if(!empty){
            input.each(function(){
                $(this).parent("td").html($(this).val());
            });         
            $(this).parents("tr").find(".add1_3, .edit1_3").toggle();
            $(".addnewbtn").removeAttr("disabled");
        }       
    });
// Edit row on edit button click
    $(document).on("click", ".edit1_3", function(){     
        $(this).parents("tr").find("td:nth-child(5)").each(function(){
            $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
        });     
        $(this).parents("tr").find(".add1_3, .edit1_3").toggle();
        $(".addnewbtn").attr("disabled", "disabled");
    });
    // Delete row on delete button click
    $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
        $(".addnewbtn").removeAttr("disabled");
    });

    $("#creatProduct").modal('hide'); //this code keep always inside the createNewData()function. Otherwies modal will stand still
}

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	
});

// =================================tr1==============================
function edit1(){
    tr1 = document.getElementById("tr1");
    //console.log(tr1);
    cell_value0 = tr1.cells[0].innerHTML;
    cell_value1 = tr1.cells[1].innerHTML;
    cell_value2 = tr1.cells[2].innerHTML;
    cell_value3 = tr1.cells[3].innerHTML;
    cell_value4 = tr1.cells[4].innerHTML;
    cell_value5 = tr1.cells[5].innerHTML;
    tr1.innerHTML = '<td><input type="text" id="fname1" value='+cell_value0+' name="fname1" class="form-control"></td>'+
    				'<td><button type="button" id="fnsub1" class="btn btn-success" name="fnsub1" value="Save">Edit</button></td>' +
                    '<td><input type="text" id="lname1" value='+cell_value2+' name="lname1" class="form-control"></td>'+
    				'<td><button type="button" id="lnsub1" class="btn btn-success" name="lnsub1" value="Save">Edit</button></td>' +
                    '<td><input type="text" id="email1" value='+cell_value4+' name="email1" class="form-control"></td>'+
    				'<td><button type="button" id="esub1" class="btn btn-success" name="esub1" value="Save">Edit</button></td>' +
                    '<td><button type="button" id="savebtn1" class="btn btn-success" name="submit" value="Save" onclick="update_edit1()">Save</button></td>'
}




function update_edit1(){
    cell_value0 = document.getElementById("fname1").value;
    cell_value1 = document.getElementById("fnsub1").value;
    cell_value2 = document.getElementById("lname1").value;
    cell_value3 = document.getElementById("lnsub1").value;
    cell_value4 = document.getElementById("email1").value;
    cell_value5 = document.getElementById("esub1").value;
    tr1.innerHTML = '<td>'+cell_value0+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_1">Edit</a></td>'+
                    '<td>'+cell_value2+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_2">Edit</a></td>'+
                    '<td>'+cell_value4+'</td>'+
                    '<td><a class="btn btn-success" id="tdId1_3">Edit</a></td>'+
                    '<td><a class="btn btn-success" id="edit1" onclick="edit1()">Edit</a>'+
                    '<a class="btn btn-danger" >Delete</a>'+
                    '</td>'

}


// ====================================1st col editbtn=============================
function tdFunc1(){
    tr1 = document.getElementById("tr1");
    //console.log(tr1);
    cell_value0 = tr1.cells[0].innerHTML;
    cell_value1 = tr1.cells[1].innerHTML;
    cell_value2 = tr1.cells[2].innerHTML;
    cell_value3 = tr1.cells[3].innerHTML;
    cell_value4 = tr1.cells[4].innerHTML;
    cell_value5 = tr1.cells[5].innerHTML;
    tr1.innerHTML = '<td><input type="text" id="fname3" value='+cell_value0+' name="fname1" class="form-control"></td>'+
    				'<td><button type="button" id="fnsub3" class="btn btn-success" name="fnsub1" value="Save" onclick="update_tdFunc1()">Save</button></td>' +
                    '<td><input type="btn" id="lname3" value='+cell_value2+' name="lname1" class="form-control"></td>'+
    				'<td><button type="button" id="lnsub3" class="btn btn-success" name="lnsub1" value="Save">Edit</button></td>' +
                    '<td><input type="btn" id="email3" value='+cell_value4+' name="email1" class="form-control"></td>'+
    				'<td><button type="button" id="esub3" class="btn btn-success" name="esub1" value="Save">Edit</button></td>' +
                    '<td><button type="button" id="savebtn2" class="btn btn-success" name="submit" value="Save">Save</button></td>'
}


function update_tdFunc1(){
    cell_value0 = document.getElementById("fname3").value;
    cell_value1 = document.getElementById("fnsub3").value;
    cell_value2 = document.getElementById("lname3").value;
    cell_value3 = document.getElementById("lnsub3").value;
    cell_value4 = document.getElementById("email3").value;
    cell_value5 = document.getElementById("esub3").value;
    tr1.innerHTML = '<td>'+cell_value0+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_1" onclick="tdFunc1()">Edit</a></td>'+
                    '<td>'+cell_value2+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_2">Edit</a></td>'+
                    '<td>'+cell_value4+'</td>'+
                    '<td><a class="btn btn-success" id="tdId1_3">Edit</a></td>'+
                    '<td><a class="btn btn-success" id="edit1" onclick="edit1()">Edit</a>'+
                    '<a class="btn btn-danger" >Delete</a>'+
                    '</td>'

}


// ====================================2nd tcol editbtn=============================
function tdFunc2(){
    tr1 = document.getElementById("tr1");
    //console.log(tr1);
    cell_value0 = tr1.cells[0].innerHTML;
    cell_value1 = tr1.cells[1].innerHTML;
    cell_value2 = tr1.cells[2].innerHTML;
    cell_value3 = tr1.cells[3].innerHTML;
    cell_value4 = tr1.cells[4].innerHTML;
    cell_value5 = tr1.cells[5].innerHTML;
    tr1.innerHTML = '<td><input type="text" id="fname4" value='+cell_value0+' name="fname1" class="form-control"></td>'+
    				'<td><button type="button" id="fnsub4" class="btn btn-success" name="fnsub1" value="Save">Edit</button></td>' +
                    '<td><input type="btn" id="lname4" value='+cell_value2+' name="lname1" class="form-control"></td>'+
    				'<td><button type="button" id="lnsub4" class="btn btn-success" name="lnsub1" value="Save" onclick="update_tdFunc2()">Save</button></td>' +

                    '<td><input type="btn" id="email4" value='+cell_value4+' name="email1" class="form-control"></td>'+
    				'<td><button type="button" id="esub4" class="btn btn-success" name="esub1" value="Save">Edit</button></td>' +
                    '<td><button type="button" id="savebtn3" class="btn btn-success" name="submit" value="Save" onclick="update_edit1()">Save</button></td>'
}


function update_tdFunc2(){
    cell_value0 = document.getElementById("fname4").value;
    cell_value1 = document.getElementById("fnsub4").value;
    cell_value2 = document.getElementById("lname4").value;
    cell_value3 = document.getElementById("lnsub4").value;
    cell_value4 = document.getElementById("email4").value;
    cell_value5 = document.getElementById("esub4").value;
    tr1.innerHTML = '<td>'+cell_value0+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_1">Edit</a></td>'+
                    '<td>'+cell_value2+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_2"onclick="tdFunc2()">Edit</a></td>'+
                    '<td>'+cell_value4+'</td>'+
                    '<td><a class="btn btn-success" id="tdId1_3">Edit</a></td>'+
                    '<td><a class="btn btn-success" id="edit1" onclick="edit1()">Edit</a>'+
                    '<a class="btn btn-danger" >Delete</a>'+
                    '</td>'

}

// ====================================3rd col editbtn=============================

function tdFunc3(){
    tr1 = document.getElementById("tr1");
    //console.log(tr1);
    cell_value0 = tr1.cells[0].innerHTML;
    cell_value1 = tr1.cells[1].innerHTML;
    cell_value2 = tr1.cells[2].innerHTML;
    cell_value3 = tr1.cells[3].innerHTML;
    cell_value4 = tr1.cells[4].innerHTML;
    cell_value5 = tr1.cells[5].innerHTML;
    tr1.innerHTML = '<td><input type="text" id="fname5" value='+cell_value0+' name="fname1" class="form-control"></td>'+
    				'<td><button type="button" id="fnsub5" class="btn btn-success" name="fnsub1">Edit</button></td>' +
                    '<td><input type="text" id="lname5" value='+cell_value2+' name="lname1" class="form-control"></td>'+
    				'<td><button type="button" id="lnsub5" class="btn btn-success" name="lnsub1">Edit</button></td>' +
                    '<td><input type="text" id="email5" value='+cell_value4+' name="email1" class="form-control"></td>'+
                    '<td><button type="button" id="esub5" class="btn btn-success" name="esub1" value="Save" onclick="update_tdFunc3()">Save</button></td>' +
                    '<td><button type="button" id="savebtn4" class="btn btn-success" name="submit" value="Save" onclick="update_edit1()">Save</button></td>'
}


function update_tdFunc3(){
    cell_value0 = document.getElementById("fname5").value;
    cell_value1 = document.getElementById("fnsub5").value;
    cell_value2 = document.getElementById("lname5").value;
    cell_value3 = document.getElementById("lnsub5").value;
    cell_value4 = document.getElementById("email5").value;
    cell_value5 = document.getElementById("esub5").value;
    tr1.innerHTML = '<td>'+cell_value0+'</td>'+
    				'<td><a class="btn btn-success" id="tdId1_1">Edit</a></td>'+
                    '<td>'+cell_value2+'</td>'+
                    '<td><a class="btn btn-success" id="tdId1_2">Edit</a></td>'+
                    '<td>'+cell_value4+'</td>'+
                    '<td><a class="btn btn-success" id="tdId1_3"onclick="tdFunc3()">Edit</a></td>'+
                    '<td class="col_center"><a class="btn btn-success" id="edit1" onclick="edit1()">Edit</a>'+
                    '<a class="btn btn-danger" >Delete</a>'+
                    '</td>'

}


// =======================================delete==================================
function delete1(){

    var r = confirm("Press Ok to delete this row"); //confirm always return true and false
    if(r==true){
        document.getElementsByTagName("tbody")[0].deleteRow(0);
    }
}






