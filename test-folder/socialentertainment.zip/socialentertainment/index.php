<!DOCTYPE html>
<html>
  <head>
    <title>BD Social Entertainment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="layout/styles/font-awesome.all.min.css" rel="stylesheet" type="text/css" media="all">
    <link href="layout/styles/bootstrap-v-3.4.1-bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flickity/2.2.0/flickity.min.css">
    <link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

    
    <style>
    </style>
  </head>
  <body id="top" class="homepagePreload">
     <!-- Preloader -->
    <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
    </div>
    <!-- End Preloader -->
  <div class="column">
    <div class="column-inner">
        <div class="wrapper row0">
          <div class="header clear">
            <div class="logo floatleft">
              <a href="index.html"><img src="images/demo/selogo.png" alt=""></a>
            </div>
            <div class="headermenu floatleft">
              <ul>
                <li><a href="index.html" target="_top">Home</a></li>
                <li><a href="">About Us </a></li>
                <li><a href=""> Contact Us </a></li>
                <li><a href="registration/register.php" target="_blank">Registration</a></li>
                <li><a href="pages/login-modal-form.html">Login</a></li>
              </ul>
            </div>
            <div class="header_right floatright">
              <div class="social_share">
                <a href="" target="_blank"><img src="images/demo/twitter.png" alt=""></a>
                <a href="https://www.facebook.com/" target="_blank"><img src="images/demo/facebook.png" alt=""></a>
                <a href="" target="_blank"><img src="images/demo/feed.png" alt=""></a>
              </div>
              <div id="search">
                <div class="button-search"></div>
                <input type="text" value="Search..." onfocus="if (this.value == 'Search...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search...';}">
              </div>
            </div>
            </div> <!-- header end here -->
            <nav id="mainmenu" class="clear">
              <ul class="clear full_corner">
                <li class="active"><a href="index.html">Home</a></li>
                <li><a class="drop" href="#"> Browse Page</a>
                  <ul>
                    <li><a href="pages/portfolio.html">Portfolio</a></li>
                    <li><a href="pages/gallery.html">Gallery</a></li>
                    <li><a href="pages/our-event-activity.html">Our Event Activities</a></li>
                    <li><a href="pages/order-ticket-page.html">Get Your Ticket</a></li>
                    <li><a href="pages/payment-page.html">payment-Method</a></li>
                    <li><a href="registration/register.html">Registration</a></li>
                    <li><a href="pages/login-modal-form.html">Log In</a></li>
                    <li><a href="pages/signup-signin.html">Sign out</a></li>
                  </ul>
              </li>
              <li><a class="drop" href="#">Upcoming Events</a>
                <ul>
                  <li><a href="#">Wedding Celebration</a></li>
                  <li><a href="#">General Festival</a></li>
                </ul>
              </li>
              <li><a href="pages/order-ticket-page.html">Order Ticket</a></li>
              <li><a class="drop" href="#">On Any Date</a>
                  <ul>
                    <li><a href="#">Today</a></li>
                    <li><a href="#">Tomorrow</a></li>
                    <li><a href="#">This Weekend</a></li>
                    <li><a href="#">This Week</a></li>
                    <li><a href="#">Next Week</a></li>
                    <li><a href="#">This Month</a></li>
                    <li><a href="#">Next Month</a></li>
                    <li><a href="#">Pick a Date</a></li>
                  </ul>
              </li>
              <li><a class="drop" href="#">Categories</a>
                <ul>
                  <li><a href="#">Art</a></li>
                  <li><a class="drop" href="#">Business</a>
                    <ul>
                      <li><a href="">Charity & Causes</a></li>
                      <li><a href="">Film & Media</a></li>
                      <li><a href="">Community</a></li>
                    </ul>
                  </li>
                </ul>
             </li>
             <li><a class="drop" href="#">Help</a>
                <ul>
                  <li><a href="#">How it Works.</a></li>
                  <li><a href="#">What does it cost to create an event?</a></li>
                  <li><a href="#">Where are my tickets?</a></li>
                  <li><a href="#">How to contact the event organizer?</a></li>
                    <ul>
                      <li><a href="#">Submenu</a></li>
                      <li><a href="#">Sub menu</a></li>
                    </ul>
                </ul>
              </li>
              <li><a class="drop" href="#">Organizer</a>
              <ul>
                <li><a href="pages/ticket-order-page.html">Tickets(0)</a></li>
                <li><a href="#">Links(3)</a></li>
                <li><a href="#">Following(0)</a></li>
                <li><a href="#">collections</a></li>
                <li><a href="#">Interests</a></li>
                <li><a href="#">Manage Event</a></li>
                <li><a href="#">Organizer Profile</a></li>
                <li><a href="#">Contacts</a></li>
                <li><a href="pages/register-modal-form.html">Account Setting</a></li>
                <li><a href="pages/login-modal-form.html">Logout</a></li>
              </ul>
            </li>
        </ul>
        <!-- ################################################################################################ -->
      </nav>
    </div> <!-- wrapper end here -->

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
    <div class="wrapper">
      <div id="slider">
         <div id="slide-wrapper" class="rounded clear ticket-detail-info">
    <!-- ################################################################################################ -->
    
            <figure id="slide-1"><a class="view" href="pages/blog1.html"><img src="images/demo/slider/slider960x350-1.gif" alt=""></a>
              <figcaption>
                <time class="listing-hero-date" datetime="2019-12-08">
                  <p class="listing-hero-image--month">Dec</p>
                  <p class="listing-hero-image--day">08</p>
                </time>
                <div class="l-align-left">
                  <h1 class="listing-hero-title" data-automation="listing-title"><a href="pages/blog1.html">4TH INTERNATIONAL CONFERENCE ON GLOBALIZATION, ENTREPRENEURSHIP AND EMERGIN...</a></h1>
                  <a href="">by Centre for Innovative Leadership Navigation (CILN)</a>
                </div>
                <div class="js-display-price-container listing-hero-footer hide-small hide-medium" data-automation="micro-ticket-box-price">
                  
                </div>
              
                <p class="right"><a href="#">Continue Reading &raquo;</a></p>
                <div class="js-display-price">
                  £300 – £400
                </div>
                  <a href="pages/order-ticket-page.html" id="ticket-btn" type="button" class="js-embed-ticket-modal-btn " data-automation="ticket-modal-btn" aria-haspopup="true"> Get Ticket
                  </a>
        
              </figcaption>
            </figure>

  
            <figure id="slide-2"><a class="view" href="pages/blog2.html"><img src="images/demo/slider/slider960x350-2.gif" alt=""></a>
              <figcaption>
                  <time class="listing-hero-date" datetime="2019-12-08">
                    <p class="listing-hero-image--month">Dec</p>
                    <p class="listing-hero-image--day">08</p>
                  </time>
                  <div class="l-align-left">
                    <h1 class="listing-hero-title" data-automation="listing-title"><a href="pages/blog2.html">4TH INTERNATIONAL CONFERENCE ON GLOBALIZATION, ENTREPRENEURSHIP AND EMERGIN...</a></h1>
                    <a href="">by Centre for Innovative Leadership Navigation (CILN)</a>
                  </div>
                  <div class="js-display-price-container listing-hero-footer hide-small hide-medium" data-automation="micro-ticket-box-price">
                    
                  </div>
                
                  <p class="right"><a href="#">Continue Reading &raquo;</a></p>
                  <div class="js-display-price">
                    £300 – £400
                  </div>
                    <a href="pages/order-ticket-page.html" id="ticket-btn" type="button" class="js-embed-ticket-modal-btn " data-automation="ticket-modal-btn" aria-haspopup="true"> Get Ticket
                    </a>
                </figcaption>
              </figure>

              <figure id="slide-3"><a class="view" href="pages/blog1.html"><img src="images/demo/slider/slider960x350-3.gif" alt=""></a>
                <figcaption>
                  <time class="listing-hero-date" datetime="2019-12-08">
                    <p class="listing-hero-image--month">Dec</p>
                    <p class="listing-hero-image--day">08</p>
                  </time>
                  <div class="l-align-left">
                    <h1 class="listing-hero-title" data-automation="listing-title"><a href="pages/blog2.html">4TH INTERNATIONAL CONFERENCE ON GLOBALIZATION, ENTREPRENEURSHIP AND EMERGIN...</a></h1>
                    <a href="">by Centre for Innovative Leadership Navigation (CILN)</a>
                  </div>
                  <div class="js-display-price-container listing-hero-footer hide-small hide-medium" data-automation="micro-ticket-box-price">
                  </div>
                
                  <p class="right"><a href="#">Continue Reading &raquo;</a></p>
                  <div class="js-display-price">
                    £300 – £400
                  </div>
                    <a href="pages/order-ticket-page.html" id="ticket-btn" type="button" class="js-embed-ticket-modal-btn " data-automation="ticket-modal-btn" aria-haspopup="true">Get Ticket
                    </a>
              </figcaption>
            </figure>

            <figure id="slide-4"><a class="view" href="pages/blog2.html"><img src="images/demo/slider/slider960x350-4.gif" alt=""></a>
              <figcaption>
                  <time class="listing-hero-date" datetime="2019-12-08">
                    <p class="listing-hero-image--month">Dec</p>
                    <p class="listing-hero-image--day">08</p>
                  </time>
                  <div class="l-align-left">
                    <h1 class="listing-hero-title" data-automation="listing-title"><a href="pages/blog2.html">4TH INTERNATIONAL CONFERENCE ON GLOBALIZATION, ENTREPRENEURSHIP AND EMERGIN...</a></h1>
                    <a href="">by Centre for Innovative Leadership Navigation (CILN)</a>
                  </div>
                  <div class="js-display-price-container listing-hero-footer hide-small hide-medium" data-automation="micro-ticket-box-price">
                    
                  </div>
                
                  <p class="right"><a href="#">Continue Reading &raquo;</a></p>
                  <div class="js-display-price">
                    £300 – £400
                  </div>
                    <a href="pages/order-ticket-page.html" id="ticket-btn" type="button" class="js-embed-ticket-modal-btn " data-automation="ticket-modal-btn" aria-haspopup="true">Get Ticket
                    </a>
              </figcaption>
            </figure>

            <figure id="slide-5"><a class="view" href="pages/blog1.html"><img src="images/demo/slider/slider960x350-5.gif" alt=""></a>
                <figcaption>
                  <time class="listing-hero-date" datetime="2019-12-08">
                    <p class="listing-hero-image--month">Dec</p>
                    <p class="listing-hero-image--day">08</p>
                  </time>
                  <div class="l-align-left">
                    <h1 class="listing-hero-title" data-automation="listing-title"><a href="pages/blog1.html">4TH INTERNATIONAL CONFERENCE ON GLOBALIZATION, ENTREPRENEURSHIP AND EMERGIN...</a></h1>
                    <a href="">by Centre for Innovative Leadership Navigation (CILN)</a>
                  </div>
                  <div class="js-display-price-container listing-hero-footer hide-small hide-medium" data-automation="micro-ticket-box-price">
                    
                  </div>
                
                  <p class="right"><a href="#">Continue Reading &raquo;</a></p>
                  <div class="js-display-price">
                    £300 – £400
                  </div>
                   <a href="pages/order-ticket-page.html" id="ticket-btn" type="button" class="js-embed-ticket-modal-btn " data-automation="ticket-modal-btn" aria-haspopup="true">Get Ticket
                    </a>
              </figcaption>
           </figure>

<!-- ################################################################################################ -->
            <ul id="slide-tabs">
            <li><a href="#slide-1">4TH INTL CONFERENCE GLOBALIZATION</a></li>
            <li><a href="#slide-2">Monthly First Friday Fair Business- Dhaka</a></li>
            <li><a href="#slide-3">Academic Governance-2019</a></li>
            <li><a href="#slide-4">Our BD Wedding Ceremony Planners</a></li>
            <li><a href="#slide-5">Startup Funding in Dhaka to Raise Money</a></li>
            </ul>
<!-- ################################################################################################ -->
        </div>
    </div>
  </div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
  <div class="wrapper row3">
    <div class="rounded homecolor">
      <main class="main-container clear">
      <!-- main body -->
<!-- ################################################################################################ -->
        <div class="group btmspace-30">
        <!-- Left Column -->
            <div class="one_quarter first">
  <!-- ################################################################################################ -->
              <ul class="nospace">
                <li class="btmspace-15"><a href="#"><em class="live-event-heading">Live Event 2</em> <img class="borderedbox" src="images/demo/home/220x95-1.png" alt=""></a></li>
                <li class="btmspace-15"><a href="#"><em class="live-event-heading">Present Event</em> <img class="borderedbox" src="images/demo/home/220x95-2.png" alt=""></a></li>
                <li class="btmspace-15"><a href="#"><em class="live-event-heading">Past Event 53</em> <img class="borderedbox" src="images/demo/home/220x95-3.png" alt=""></a></li>
                <li><a href="#"><em class="live-event-heading">Past Event 54</em> <img class="borderedbox" src="images/demo/home/220x95-4.png" alt=""></a></li>
              </ul>
  <!-- ################################################################################################ -->
            </div>
            <!-- / Left Column -->
            <!-- Middle Column -->
            <div class="one_half">
            <!-- ################################################################################################ -->
              <h2>Latest News &amp; Events</h2>
              <ul class="nospace spacezero listing">
                <li class="clear">
                  <div class="imgl borderedbox"><img src="images/demo/home/1.png" alt=""></div>
                  <p class="nospace spacezero btmspace-15"><a href="#"> #FoodDrink #Party </a></p>
                  <p>Tue, Jan 1 7:00 PM</p>
                  <p><a href="">Social Entertainment 2019 Event Holiday Gift Bundle</a></p>
                  
                </li>
                <li class="clear">
                  <div class="imgl borderedbox"><img src="images/demo/home/2.png" alt=""></div>
                  <p class="nospace spacezero btmspace-15"><a href="#"> #FoodDrink #Party </a></p>
                  <p>Fri, Jul 12 7:00 PM</p>
                  <p>Rosé Summer Crawl 2019 </p>
                </li>
                <li class="clear">
                  
                  <div class="imgl borderedbox"><img src="images/demo/home/3.png" alt=""></div>
                  <p class="nospace spacezero btmspace-15"><a href="#">CENTRAL'S ANNIVERSARY FUNDRAISER CHAMPAGNE</a></p>
                  <p>Sun, Mar 17 11:00 AM</p>
                  <p>CENTRAL Pizza & Bar, Lafayette</p>
                </li>
              </ul>
              <!-- ############################################################################ -->
            </div>
            <!-- / Middle Column -->
            <!-- Right Column -->
            <div class="one_quarter sidebar">
            <!-- ################################################################################################ -->
              <div class="sdb_holder">
                <div class="mediacontainer clear">
                  <video class="video" width="220" height="180" controls>
                    <source src="videos/Wedding.mp4" type="video/mp4"></video>  
                    <!-- <img src="images/demo/video.gif" alt=""> -->
                    <!-- <p class="more-video"><a href="#">View More Tour Videos</a></p> -->
                </div>
              </div>
           
              <div class="">

                <div class="sitebox">
                  <div class="heading"><h2>Upcoming Events</h2></div>
                  <div class="content">
                    <div class="list">
                      <ul>
                        <li><a href="pages/blog1.html">ApollyCon 2020 </a></li>
                        <li><a href="pages/blog2.html">2019 Around The World Cultural Food Festival</a></li>
                        <li><a href="pages/blog1.html">5th International Day of Yoga</a></li>
                        <li><a href="pages/blog2.html">Carifesta Music & Arts Festival</a></li>
                        <li><a href="pages/blog1.html">Chinatown Community Festival</a></li>
                      </ul>
                    </div>
                  </div>
                </div>

              </div>

            </div><!--one quarter sidebar end-->
        </div> <!-- /group btmspace-30 -->
        <!-- ################################################################################################ -->
        <!-- ################################################################################################ -->
          <h2 class="blogheading">Live your best life</h2>
          <div class="blog-group">
            <div class="one_three_col">
              <div class="nospace">
                <a href="pages/blog2.html"><img src="images/demo/blog/blog1.jpg" alt=""></a>
                <div class="time-card">
                    <div class="width48"><span class="red">Dec</span>8</div>
                    <div class="time-thumbnail">
                    <span class="time-content"><a href="pages/blog1.html">4TH INTERNATIONAL CONFERENCE ON ...</a></span>
                    <p>Sun, Dec 8, 9:30am</p>
                    <p>Daffodil International University, Dhaka-1207,...</p>
                    <p>Starts at £300.00</p>
                    </div>
                </div>
              </div>
            </div>
            <div class="one_three_col">
              <div class="nospace">
               <a href="pages/blog1.html"><img src="images/demo/blog/blog4.jpg" alt=""></a> 
                <div class="time-card">
                    <div class="width48"><span class="red">Dec</span>8</div>
                    <div class="time-thumbnail">
                    <span class="time-content"><a href="pages/blog2.html">STARTUP FUNDING IN DHAKA: HOW TO RAISE MONEY FOR YOUR IDEA...</a></span> 
                    <p>Tuesday, July 2, 2019, 9:30am</p>
                    <p>Daffodil International University, Dhaka-1207...</p>
                    <p>Starts at £300.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="one_three_col">
                <div class="nospace">
                 <a href="pages/blog2.html"><img src="images/demo/blog/blog3.jpg" alt=""></a> 
                  <div class="time-card">
                      <div class="width48"><span class="red">Dec</span>8</div>
                      <div class="time-thumbnail">
                      <span class="time-content"><a href="pages/blog1.html">4TH INTERNATIONAL CONFERENCE ON ...</a></span>
                      <p>Sun, Dec 8, 9:30am</p>
                      <p>Daffodil International University, Dhaka-1207,...</p>
                      <p>Starts at £300.00</p>
                      </div>
                   </div>
                  </div>
                </div>
              </div>



          <!-- ################################################################################################ -->
          <!-- ################################################################################################ -->
        <h1 class="brand">Our Available Brand </h1>
        <div class="brands-wrap">
          <div class="brand-carousel" id="brandCarousel">
            <div class="gallery-cell">
              <img src="images/demo/brand/brand1.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/brand2.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/brand3.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/1.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/2.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/3.png" />
            </div>
             <div class="gallery-cell">
              <img src="images/demo/brand/4.png" />
            </div>
          </div>
        </div>
        

        <div id="twitter" class="group">
          <div class="one_quarter twitter first center"><a href="#"><i class="fa fa-twitter fa-3x"></i><br>
          Follow Us On Twitter</a>
          </div>
          <div class="three_quarter bold">
           <p>BD Social Entertainment is a platform for live experiences that allows anyone to create, share, find and attend events that fuel their passions and enrich their lives. From music festivals, marathons, conferences, community rallies, and fundraisers. Our mission is to bring the world together through live experiences.</p>
          </div>
        </div>

<!-- ################################################################################################ -->
<!-- / main body -->
        <div class="clear"></div>
      </main>
    </div>
  </div>
    <!-- ################################################################################################ -->
    <!-- ################################################################################################ -->
    <!-- ################################################################################################ -->
    <!-- ------------Footer------------- -->
  <footer>
    <div class="wrap-footer column">
      <div class="row block09">

        <div class="col-1-4">
          <div class="wrap-col">
            <div class="box">
              <div class="heading"><h2 class="h2ml">About Us</h2></div>
              <div class="content">
                <p>Our aim to create, share, find and attend events that fuel the passions and enrich the lives.</p>
                <p>Our mission is to bring the world together through live experiences.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-1-4">
          <div class="wrap-col">
            <div class="box">
              <div class="heading"><h2>Latest Post</h2></div>
              <div class="content color-a">
                <ul>
                  <li><a href="pages/blog1.html">ApollyCon 2020 </a></li>
                  <li><a href="pages/blog2.html">2019 Around The World Cultural Food Festival</a></li>
                  <li><a href="pages/blog1.html">5th International Day of Yoga</a></li>
                  <li><a href="pages/blog2.html">Carifesta Music & Arts Festival</a></li>
                  <li><a href="pages/blog1.html">Chinatown Community Festival</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="col-1-4">
          <div class="wrap-col">
            <div class="box">
              <div class="heading"><h2>Social Event Tags</h2></div>
              <div class="content">
                <div class="tag">
                  <a href="#">Galaxy</a><a href="#">Beatport</a><a href="#">Amazon</a><a href="#">Itunes</a><a href="#">Sonic</a><a href="#">Kpopps</a><a href="#">Summer</a><a href="#">Magical</a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-1-4">
          <div class="wrap-col">
            <div class="box">
              <div class="heading"><h2>Contact Us</h2></div>
              <div class="content">
                <ul>
                  <li>Phone : +88.01678.601.886</li>
                  <li>Email : admin@myfirstportfollio.com</li>
                  <li>Website : www.myfirstportfollio.com</li>
                </ul>
                <ul class="faico clear">
                  <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                  <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a class="faicon-rss" href="#"><i class="fa fa-rss"></i></a></li>
                </ul>
                <form class="clear" method="post" action="#">
                  <fieldset>
                    <legend class="newletter">Subscribe To Our Newsletter:</legend>
                    <input type="text" value="" placeholder="Enter Email Here&hellip;">
                    <a href="pages/signup-signin.html"><button class="fa fa-sign-in" type="submit" title="Sign Up"><em>Sign Up</em></button></a>
                  </fieldset>
                </form>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /row block09 -->

        <div class="row copyright  color-a column">
        <p style="color:#fff">Copyright &copy; 2019 - All Rights Reserved for my first portfollio only- <a href="http://www.myfirstportfollio.com" target="_blank">Ferdousbaf.com</a></p>
        </div>

    </div> <!-- /wrap-footer column -->

   </footer>
<!--  #########################################################################################
#########################################################################################
######################################################################################### -->
  </div>
</div>
  <!-- JAVASCRIPTS -->
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> -->
  <script src="layout/scripts/jquery-v3.4.0.min.js"></script>
  <!-- <script src="layout/scripts/jquery.min.js"></script>  -->
  <script src="layout/scripts/jquery.fitvids.min.js"></script>
  <script src="layout/scripts/jquery.mobilemenu.js"></script>
  <script src="layout/scripts/custom.js"></script>
  <script src="layout/scripts/tabslet/jquery.tabslet.min.js"></script>
  <script src="layout/scripts/bootstrap-v4.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/flickity/2.2.0/flickity.pkgd.min.js"></script>
  <script>
    //   for an individual element
    var flkty = new Flickity( '#brandCarousel', {
      contain: true,
      pageDots: false,
      wrapAround: true,
      freeScroll: true,
      autoPlay: 1600
    });
  </script>
  <script>
     $(document).ready(function() {
         setTimeout(function(){
            $('.homepagePreload').addClass('loaded');
            $(this).css('color','#222222');
            }, 500);
     })
  </script>
  
  <script>
    //carousel initialize

    $('.main-carousel').flickity({
  // options
      cellAlign: 'left',
      contain: true
    });

  </script>

  </body>
</html>